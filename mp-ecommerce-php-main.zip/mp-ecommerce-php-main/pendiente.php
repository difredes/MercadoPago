<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pendiente</title>
</head>

<body>
    TU COMPRA ESTA PENDIENTE, DIRIGITE A LA SUCURSAL DE "MEDIO DE PAGO EN EFECTIVO" (acá iría información pertinente a el estado pendiente)

</body>

</html>